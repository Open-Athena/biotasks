# Issue

**Title:** FIX: Propagate errors from `run_without_submitting`

## Description

Came up in  , 

This adds a  `_run_errors` attribute to `DistributedPluginBase` which is only utilized during the `run()` lifecycle, to ensure any encountered errors are properly reported.

Each distributed plugin may need to be updated, this only touches on `MultiProc` and `LegacyMultiProc`.

## Task

Modify the repository so that the issue described above is resolved. The task's test suite verifies your patch by applying it on top of the base commit `2b671ab9f5f4` and running the modified tests.