#!/bin/bash
set -uxo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd /workspace
git config --global --add safe.directory /workspace
mkdir -p /logs/verifier
git checkout 2b671ab9f5f4bcf0f88871617b6d0bcb3fd4d975 -- nipype/pipeline/plugins/tests/test_multiproc.py || true
git apply --verbose --reject - <<'EOF_R2E_TEST_PATCH'
diff --git a/nipype/pipeline/plugins/tests/test_multiproc.py b/nipype/pipeline/plugins/tests/test_multiproc.py
index e46b3a7059..266544eae0 100644
--- a/nipype/pipeline/plugins/tests/test_multiproc.py
+++ b/nipype/pipeline/plugins/tests/test_multiproc.py
@@ -78,6 +78,11 @@ def _list_outputs(self):
         return outputs
 
 
+class ErrorInterface(SingleNodeTestInterface):
+    def _run_interface(self, runtime):
+        raise RuntimeError("This is an error")
+
+
 def test_no_more_memory_than_specified(tmpdir):
     tmpdir.chdir()
     pipe = pe.Workflow(name="pipe")
@@ -157,3 +162,22 @@ def test_hold_job_until_procs_available(tmpdir):
 
     max_threads = 2
     pipe.run(plugin="MultiProc", plugin_args={"n_procs": max_threads})
+
+
+@pytest.mark.parametrize("plugin", ["MultiProc", "LegacyMultiProc"])
+def test_error_run_without_submitting(tmp_path, plugin):
+    wf = pe.Workflow(name='rws', base_dir=str(tmp_path))
+    n1 = pe.Node(SingleNodeTestInterface(), name='n1')
+    n1.inputs.input1 = 1
+    n2 = pe.Node(ErrorInterface(), name='n2', run_without_submitting=True)
+    n3 = pe.Node(SingleNodeTestInterface(), name='n3')
+
+    wf.connect(
+        [
+            (n1, n2, [('output1', 'input1')]),
+            (n2, n3, [('output1', 'input1')]),
+        ]
+    ),
+
+    with pytest.raises(RuntimeError):
+        wf.run(plugin=plugin)

EOF_R2E_TEST_PATCH
R2E_APPLY_RC=$?
if [ "$R2E_APPLY_RC" -ne 0 ]; then
  echo "0.000000" > /logs/verifier/reward.txt
  printf '%s' '{"reward": 0.0, "resolved": false, "parse_status": "test_patch_apply_failed"}' > /logs/verifier/reward-details.json
  echo "R2E: test_patch failed to apply (rc=$R2E_APPLY_RC) — failing closed" >&2
  exit 0
fi
( python -m pip install --no-deps --no-build-isolation --no-index -e . && python -m pytest -vv nipype/pipeline/plugins/tests/test_multiproc.py ) > /logs/verifier/test_output.log 2>&1
TEST_EXIT_CODE=$?
cat /logs/verifier/test_output.log
python3 "$SCRIPT_DIR/verifier.py" --log /logs/verifier/test_output.log --f2p "$SCRIPT_DIR/f2p.json" --p2p "$SCRIPT_DIR/p2p.json" --test-cmds 'python -m pip install --no-deps --no-build-isolation --no-index -e . python -m pytest -vv nipype/pipeline/plugins/tests/test_multiproc.py' --exit-code "$TEST_EXIT_CODE" --out-dir /logs/verifier || { [ "$TEST_EXIT_CODE" -eq 0 ] && echo "1.0" > /logs/verifier/reward.txt || echo "0.0" > /logs/verifier/reward.txt; }
git checkout 2b671ab9f5f4bcf0f88871617b6d0bcb3fd4d975 -- nipype/pipeline/plugins/tests/test_multiproc.py || true
exit 0
