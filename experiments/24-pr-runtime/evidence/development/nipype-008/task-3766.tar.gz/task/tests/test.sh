#!/bin/bash
set -uxo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd /workspace
git config --global --add safe.directory /workspace
mkdir -p /logs/verifier
git checkout b4c671fe5581534bcfd64224db17fd4dc1d9464c -- nipype/pipeline/engine/tests/test_workflows.py || true
git apply --verbose --reject - <<'EOF_R2E_TEST_PATCH'
diff --git a/nipype/pipeline/engine/tests/test_workflows.py b/nipype/pipeline/engine/tests/test_workflows.py
index d3ecc542ce..d01c8fd372 100644
--- a/nipype/pipeline/engine/tests/test_workflows.py
+++ b/nipype/pipeline/engine/tests/test_workflows.py
@@ -2,6 +2,7 @@
 # vi: set ft=python sts=4 ts=4 sw=4 et:
 """Tests for the engine workflows module"""
 
+from copy import deepcopy
 from glob import glob
 import os
 from shutil import rmtree
@@ -34,6 +35,31 @@ def test_connect():
     assert pipe._graph.get_edge_data(mod1, mod2) == {"connect": [("output1", "input1")]}
 
 
+def _add_one(x):
+    return x + 1
+
+
+def test_connect_preserves_input_list():
+    """Regression test for connection list mutation.
+
+    This only occurs when the connection contains an inline function node.
+    """
+    pipe = pe.Workflow(name="pipe")
+    pipe.config["execution"]["poll_sleep_duration"] = 0.01
+    mod1 = pe.Node(EngineTestInterface(input1=2), name="mod1")
+    mod2 = pe.MapNode(EngineTestInterface(), iterfield="input1", name="mod2")
+
+    connection_list = [(mod1, mod2, [(('output1', _add_one), 'input1')])]
+    expected = [
+        (in_node, out_node, deepcopy(connections))
+        for in_node, out_node, connections in connection_list
+    ]
+    assert connection_list == expected
+
+    pipe.connect(connection_list)
+    assert connection_list == expected
+
+
 def test_add_nodes():
     pipe = pe.Workflow(name="pipe")
     mod1 = pe.Node(EngineTestInterface(), name="mod1")

EOF_R2E_TEST_PATCH
R2E_APPLY_RC=$?
if [ "$R2E_APPLY_RC" -ne 0 ]; then
  echo "0.000000" > /logs/verifier/reward.txt
  printf '%s' '{"reward": 0.0, "resolved": false, "parse_status": "test_patch_apply_failed"}' > /logs/verifier/reward-details.json
  echo "R2E: test_patch failed to apply (rc=$R2E_APPLY_RC) — failing closed" >&2
  exit 0
fi
( python -m pip install --no-deps --no-build-isolation --no-index -e . && python -m pytest -vv nipype/pipeline/engine/tests/test_workflows.py ) > /logs/verifier/test_output.log 2>&1
TEST_EXIT_CODE=$?
cat /logs/verifier/test_output.log
python3 "$SCRIPT_DIR/verifier.py" --log /logs/verifier/test_output.log --f2p "$SCRIPT_DIR/f2p.json" --p2p "$SCRIPT_DIR/p2p.json" --test-cmds 'python -m pip install --no-deps --no-build-isolation --no-index -e . python -m pytest -vv nipype/pipeline/engine/tests/test_workflows.py' --exit-code "$TEST_EXIT_CODE" --out-dir /logs/verifier || { [ "$TEST_EXIT_CODE" -eq 0 ] && echo "1.0" > /logs/verifier/reward.txt || echo "0.0" > /logs/verifier/reward.txt; }
git checkout b4c671fe5581534bcfd64224db17fd4dc1d9464c -- nipype/pipeline/engine/tests/test_workflows.py || true
exit 0
