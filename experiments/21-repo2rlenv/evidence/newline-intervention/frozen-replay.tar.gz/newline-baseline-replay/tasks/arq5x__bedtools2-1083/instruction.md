# Issue

**Title:** typo fix: chromomsome

## Description

Typo, but I think I'm going to start referring to maternal haplotypes as "chromomsomes"

## Task

Modify the repository so that the issue described above is resolved. The repository is checked out at base commit `6213eebf00d3`. Edit files in place; the verifier captures your changes via `git diff` and scores them against an oracle patch using SWE-RL-style diff-similarity reward.