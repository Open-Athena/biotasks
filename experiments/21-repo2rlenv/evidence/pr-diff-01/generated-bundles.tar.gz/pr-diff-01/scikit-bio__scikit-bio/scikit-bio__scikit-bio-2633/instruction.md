# Issue

**Title:** Fix ANCOM-BC2 EM responsibility underflow

## Description

.

## Summary

This fixes a numerical edge case in `ancombc2`'s sampling-bias EM step.

For features with extremely small coefficient variances, all three weighted Gaussian densities can underflow to zero. The responsibility normalization then becomes `0 / 0`, producing `NaN`. Those NaNs propagate into the mixture weights and eventually into the quantile probabilities used by `_estimate_bias_var`, where NumPy raises:

```text
ValueError: Quantiles must be in the range [0, 1]
```

The R ANCOMBC implementation explicitly replaces undefined responsibilities with zero. This patch reproduces that behavior without first creating NaNs: it sums the responsibilities into an existing workspace and uses a guarded `np.divide`. If the normalizer is zero, all three numerators are already zero, so the responsibility column is left at zero.

The patch also mirrors ANCOMBC's handling of a related M-step degeneracy: if a negative or positive mixture component receives zero total responsibility, its `l1`/`l2` update is set to zero instead of evaluating `0 / 0`.

## Tests

Adds the minimal reproducer from #2631 as an end-to-end regression test. The affected group coefficients are compared against the R ANCOMBC reference values reported in the issue:

- LFC: `[-1.08292235, 0.16646377, -0.13155807]`
- p-value: `[0.25770796, 0.85244671, 0.87755871]`

Existing `_estimate_bias_em` tests continue to cover ordinary, non-underflow inputs.

## Notes

A log-space responsibility calculation, for example using `logsumexp`, would avoid underflow more generally, but it would change behavior in precisely the regime where ANCOMBC currently assigns zero responsibilities. This patch intentionally preserves R-package behavior and keeps the change scoped to the reported bug.

***

Please complete the following checklist:

* [x] I have read the [contribution guidelines](https://scikit.bio/contribute.html).

* [x] I have documented all public-facing changes in the [changelog](https://github.com/scikit-bio/scikit-bio/blob/main/CHANGELOG.md).

* [ ] **This pull request includes code, documentation, or other content derived from external source(s).** If this is the case, ensure the external source's license is compatible with scikit-bio's [license](https://github.com/scikit-bio/scikit-bio/blob/main/LICENSE.txt). Include the license in the `licenses` directory and add a comment in the code giving proper attribution. Ensure any other requirements set forth by the license and/or author are satisfied.

  - **It is your responsibility to disclose** code, documentation, or other content derived from external source(s). If you have questions about whether something can be included in the project or how to give proper attribution, include those questions in your pull request and a reviewer will assist you.

* [x] This pull request does not include code, documentation, or other content derived from external source(s).

Note: [This document](https://scikit.bio/devdoc/review.html) may also be helpful to see some of the things code reviewers will be verifying when reviewing your pull request.

## Task

Modify the repository so that the issue described above is resolved. The repository is checked out at base commit `71286a24bddf`. Edit files in place; the verifier captures your changes via `git diff` and scores them against an oracle patch using SWE-RL-style diff-similarity reward.