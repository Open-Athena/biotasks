#!/bin/bash
set -uxo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd /workspace
git config --global --add safe.directory /workspace
mkdir -p /logs/verifier
rm -f /logs/verifier/reward.txt /logs/verifier/reward.json /logs/verifier/reward-details.json
git add -A
git diff --cached e6f51b1ef6de5fba07cb184fa5152ee8920abd87 > /tmp/predicted.patch
: 'START_VERIFY_OUTPUT'
python3 "$SCRIPT_DIR/verifier.py" \
    "$SCRIPT_DIR/oracle.patch" \
    /tmp/predicted.patch \
    "$SCRIPT_DIR/instruction.md"
: 'END_VERIFY_OUTPUT'
exit 0
