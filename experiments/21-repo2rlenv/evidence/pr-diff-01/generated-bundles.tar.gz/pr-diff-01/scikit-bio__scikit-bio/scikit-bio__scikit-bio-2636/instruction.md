# Issue

**Title:** BUG: BPTree GPU dispatch: out-of-memory fallback, device selection, and probe caching

## Description

# Summary

This PR fixes three behaviours of `BPTree`'s GPU dispatch, the code that sends the batch operations and `cophenet` of a tree on a GPU to the Numba GPU kernels:

- A single call that ran out of device memory turned the GPU off for the rest of the process.
- Every call probed for the Numba GPU extension several times over, each time re-trying the import of an extension that is not installed.
- The kernels ran on GPU 0, whatever GPU the tree is on.

## Main Changes

### 1. Running out of device memory turned the GPU off

**Problem**

- When a GPU kernel raises, the batch operations and `cophenet` call `_mark_gpu_unavailable`, which routes that backend (CuPy or PyTorch) to the CPU engines for the rest of the process. That is right for a kernel that cannot build or run on the system.
- Running out of device memory, though, is a property of one call, e.g. a batch of queries, or a tree's index, larger than the free memory. It was handled the same way, so after one such call every later batch and `cophenet` call on any CuPy or PyTorch tree ran on the CPU, small ones included.

**Fix**

- An out-of-memory error is now told apart from other failures. That call is computed on the CPU with a warning, and later calls still use the GPU.
- Each library raises its own error, so the error is matched by type and message:

  | Library | Out-of-memory error |
  |---|---|
  | CuPy | `MemoryError` (`OutOfMemoryError`) |
  | PyTorch | `torch.OutOfMemoryError` ("CUDA out of memory") |
  | numba-cuda, numba-cuda-mlir | `CudaAPIError` naming `CUDA_ERROR_OUT_OF_MEMORY` |
  | numba-hip (ROCm, not tested) | `hipErrorOutOfMemory` |

- Allocations made outside the kernel call, i.e. the result of a batch on the queries' device and the `cophenet` matrix, still raise their error, as before.

### 2. The GPU extension was probed on every call

**Problem**

- Each batch operation and `cophenet` worked out what `engine="fast"` would mean even when another engine was asked for, and did so again for each kernel it ran (3 per `cophenet`).
- On a GPU tree, that means probing for the Numba GPU module, which tries to import each GPU extension in turn. Python does not remember a failed import, so the extension that is not installed (`numba_cuda_mlir` beside numba-cuda) was searched for again on every probe. With numba-cuda, this probe took about 22 µs, several times per call.

**Fix**

- The engine is resolved once per call, and what `"fast"` means is worked out only when `engine="fast"` is asked for.
- The probe is cached for the process, as what is installed does not change within it. Kernels that failed are still checked on every call, so a backend whose kernels cannot run still goes to the CPU.

### 3. The kernels ran on GPU 0, not on the tree's GPU

**Problem**

- The batch operations and `cophenet` uploaded the tree's index, and launched their kernels, on the current device of the Numba GPU module, which is device 0 unless selected.
- A tree on another GPU, e.g. made with `to_device(cupy, 1)` or from a tensor on `cuda:1`, had its index uploaded to GPU 0 and its kernels run there, on queries and an output in the memory of GPU 1. The result is an illegal memory access, which can leave the GPU context unusable, or a fallback that turns the GPU off for the process.
- `numba_arrays(gpu=...)` also uploaded to GPU 0.

**Fix**

- The tree's GPU (CuPy's device id, PyTorch's device index, or PyTorch's current device for `"cuda"`) is made the Numba module's current device for the upload of the index, each batch, and `cophenet`'s kernel.
- `numba_arrays(gpu=...)` of a tree on a GPU uploads to that GPU.
- Queries on a GPU other than the tree's raise `ValueError`, as array API operations on arrays of different devices do.
- A tree on the host keeps the module's current device.

## Performance and memory

Two A/B comparisons against `bp_tree`:
- **Small calls**, where the probing removed in change 2 is a large share of each call;
- **the full benchmark** used for the other BPTree PRs, to check that nothing else changes.

### Common setup

- **Builds:** `bp_tree` (5aea0f2b) against this branch, each with its extensions built in place.
- **Fresh processes:** every measurement runs in a new process, with the two builds alternating from round to round (A B, then B A, ...), so drift such as GPU clocks falls on both.
- **Machine:** Intel i7-14700HX; NVIDIA RTX 4070 Laptop GPU with CuPy 14.2; Python 3.13, NumPy 2.4.6 (numba-cuda environment) or 2.5.3 (numba-cuda-mlir environment), Numba 0.67; WSL2.
- **Code version:** the A/Bs ran before two later edits: the switch to `from functools import lru_cache` and `from contextlib import contextmanager`, and doc edits. Neither changes behaviour.
-
### Runtime

**Method**
- **Trees:** a random tree of 1,000,000 tips and a caterpillar of 100,000 tips, each with names and branch lengths; numba-cuda environment.
- **Rounds:** 6. Each round keeps the median of its trials, and the table gives the median over rounds of the ratio this PR / `bp_tree`.
- **Outputs:** every result is reduced to a checksum and compared between the builds.

**Results:** all 88 measurements had identical outputs; the median ratio is 0.999. The only two flagged were faster: GPU batch operations, which make the probes removed in change 2.

| Operation | Random, 1M tips | Caterpillar, 100K tips |
|---|---:|---:|
| **Construction:** `BPTree(B, names=..., lengths=...)` | 1.02× | 1.01× |
| **Single-node methods from Python**, 200,000 queries each: `close`, `parent`, `level_ancestor`, `lca`, `rmq`, `rMq`, `height`, `deepest_node`, `level_next`, `preorder_select`, `postorder_select` | 0.92–1.06× | 0.98–1.05× |
| **Batch operations, Cython**, 1M queries, 14 threads: `close`, `parent`, `lca`, `level_ancestor` | 1.01–1.02× | 0.97–1.05× |
| **Batch operations, Numba**, the same | 0.95–1.01× | 0.99–1.13× |
| **Batch operations, GPU**, the same, on a tree moved with `to_device(cupy)` and device queries | see below | see below |
| **Whole-tree operations:** `to_array`, `TreeNode.from_bptree`, `collapse`, `shear` of half the tips, `cophenet` of 2,000 tips (Cython, Numba) | 0.98–1.00× | 0.98–1.01× |
| **`cophenet` of 2,000 tips, GPU** | 1.01× | 1.00× |
| **Numba kernels on the CPU, 14 threads:** the `lca` of 100,000 samples of 1–20 tips, `level_next` of every node, `preorder_select` and `postorder_select` of every rank | 0.97–1.01× | 0.92–1.09× |
| **The same kernels on one CPU thread** | 1.00× | 1.00–1.04× |
| **The same kernels on the GPU** | 0.98–1.04× | 0.93–1.02× |

The GPU batch operations, 1M queries each:

| Operation | Random: `bp_tree` | this PR | ratio (per round) | Caterpillar: `bp_tree` | this PR | ratio (per round) |
|---|---:|---:|---|---:|---:|---|
| `close_batch` | 1.35 ms | 1.10 ms | **0.81** (0.78–0.95) | 1.17 ms | 0.96 ms | 0.82 (0.77–0.98) |
| `parent_batch` | 1.30 ms | 1.16 ms | 0.89 (0.78–0.99) | 1.19 ms | 1.05 ms | 0.89 (0.81–0.97) |
| `lca_batch` | 3.12 ms | 3.24 ms | 1.04 (0.95–1.16) | 2.77 ms | 2.63 ms | 0.95 (0.89–1.08) |
| `level_ancestor_batch` | 1.78 ms | 1.74 ms | 0.98 (0.86–1.11) | 1.29 ms | 1.06 ms | **0.82** (0.73–0.97) |

Bold marks the two flagged (faster in every round) and is benefitted from the probe caching. These calls take about 1–3 ms, so the 0.1–0.25 ms saved is visible. The CPU paths make no probe, so they do not change.

### Memory

Measured in one process per build, tree and round, over 2 rounds.

| Quantity | Random, 1M tips | Caterpillar, 100K tips |
|---|---:|---:|
| Navigation index (exact bytes) | 69,431,408 in both | 7,084,088 in both |
| Resident memory of the tree | 85.0 MB in both | 8.6 MB in both |
| Tree and index on the GPU after a batch call | 79.7 MB and 73.4 MB in both | 8.4 MB and 7.5 MB in both |
| Peak of a 1M-query `lca_batch` / `close_batch` | 8.0 MB in both | 8.0 MB in both |
| Peak of `to_array`, `from_bptree`, `collapse`, `shear` | within 0.75 MB | within 0.2 MB |

The peaks of the whole-tree operations vary by up to about 2 MB between runs of the same build, so these differences are noise.

The cached probe adds no measurable memory: one cache entry per GPU module checked, holding modules that are already imported.

## Scope: BPTree only

These changes apply only to `BPTree`'s GPU code in `skbio/tree/bp`. The other Numba GPU kernels in scikit-bio, the PERMANOVA and Mantel permutation tests in `skbio/stats/distance`, use their own copy of the same helpers, which this PR leaves unchanged. They still have the same gaps:

- **Out of memory:** a call that runs out of device memory turns their fused kernel off for the rest of the process.
- **Device:** their GPU buffers must belong to the default device, as their docs say; a matrix on another GPU is not detected.
- **Probe:** the probe for the Numba GPU module is not cached, so it runs on every call.

A follow-up could share one set of helpers between the two, apply these fixes to PERMANOVA and Mantel, and drop the default-device requirement from their docs.

## Testing

- Added a test per fix which fails without it.
- On a GPU, the GPU workflow's test command on CuPy with numba-cuda-mlir and with numba-cuda, and the BPTree tests on CuPy and on CUDA PyTorch, with fallbacks turned into errors. The device tests run on one GPU, with the tree reporting GPU 1 (see below).
- Locally, the full suite passes with numba-cuda (NumPy 2.4.6) and with numba-cuda-mlir (NumPy 2.5.3). Five tests outside `skbio/tree` fail in the numba-cuda environment's GPU run because its CuPy lacks cuBLAS, the same five as on `bp_tree`.

**Not tested:**
- **Several GPUs.** The device selection (change 3) is tested on a system with one GPU, by making the tree report GPU 1 and recording the device each upload and launch selects; it has not run on a second device.
- **ROCm.** The out-of-memory error of numba-hip (`hipErrorOutOfMemory`) is matched from its documented name, and its device selection relies on the same `gpus` list as numba-cuda.
- **Out of memory under a real load.** On this machine (WSL2), CUDA allocations spill into shared system memory, so the errors were produced by allocations larger than the GPU and that memory together rather than by a batch slightly too large.

Please complete the following checklist:

* [x] I have read the [contribution guidelines](https://scikit.bio/contribute.html).
* [x] I have documented all public-facing changes in the [changelog](https://github.com/scikit-bio/scikit-bio/blob/main/CHANGELOG.md).
* [ ] **This pull request includes code, documentation, or other content derived from external source(s).** If this is the case, ensure the external source's license is compatible with scikit-bio's [license](https://github.com/scikit-bio/scikit-bio/blob/main/LICENSE.txt).
* [x] This pull request does not include code, documentation, or other content derived from external source(s).

## Task

Modify the repository so that the issue described above is resolved. The repository is checked out at base commit `e6f51b1ef6de`. Edit files in place; the verifier captures your changes via `git diff` and scores them against an oracle patch using SWE-RL-style diff-similarity reward.