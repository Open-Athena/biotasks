# Issue

**Title:** Ignore Windows-style line termination in genome files

## Description

Most parts of bedtools — e.g. the main BED file parsers — can accept either Unix- or Windows-style line termination, as they explicitly trim `'\n'` and `'\r'` characters from lines as they are read in. At present, reading in genome files does not do that, leading to obscure error messages such as encountered by the OP in #998.

This PR adds a utility function to trim any CR or LF characters at the end of a string, and uses it in `NewGenomeFile::loadGenomeFileIntoMap()` which did not previously accept Windows-style CRLF-delimited files. I didn't alter `GenomeFile`; hopefully most bedtools code uses the `New…` class!

There are several other file reading classes that do their own newline trimming. It's a low priority, but they could be altered to use this utility function too if desired.

## Task

Modify the repository so that the issue described above is resolved. The repository is checked out at base commit `8c0d2cc3921e`. Edit files in place; the verifier captures your changes via `git diff` and scores them against an oracle patch using SWE-RL-style diff-similarity reward.