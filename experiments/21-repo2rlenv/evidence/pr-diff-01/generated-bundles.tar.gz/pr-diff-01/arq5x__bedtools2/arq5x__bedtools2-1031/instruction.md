# Issue

**Title:** fix coverage formatting when scale == 1

## Description

the new test prints 1e6 for previous versions of bedtools.

## Task

Modify the repository so that the issue described above is resolved. The repository is checked out at base commit `4c19da540c16`. Edit files in place; the verifier captures your changes via `git diff` and scores them against an oracle patch using SWE-RL-style diff-similarity reward.