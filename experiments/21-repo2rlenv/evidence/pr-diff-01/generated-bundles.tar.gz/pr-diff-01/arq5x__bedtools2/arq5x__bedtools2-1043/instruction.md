# Issue

**Title:** Avoid dangling reference to temporary string object

## Description

Clang produces the following warning for _Fasta.cpp_ — and `idx_path` does indeed point to something no longer valid after the semicolon:

```
src/utils/Fasta/Fasta.cpp:38:28: warning: object backing the pointer will be destroyed at the end of the full-expression [-Wdangling-gsl]
    const char *idx_path = (fname + ".fai").c_str();
                           ^~~~~~~~~~~~~~~~
```

There are two other instances of the same warning, in _BamAncillary.cpp_, but that code is never used so doesn't matter too much.

## Task

Modify the repository so that the issue described above is resolved. The repository is checked out at base commit `b891a0b6b2c6`. Edit files in place; the verifier captures your changes via `git diff` and scores them against an oracle patch using SWE-RL-style diff-similarity reward.