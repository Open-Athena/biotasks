# Issue

**Title:** genomecov: use integer when scale == 1.0

## Description

#1015

this should fix formatting.

When scale is 1, this sends an integer to cout which will avoid the scientific notation. When scale != 1, the scientific notation could persist, but would be less surprising.

## Task

Modify the repository so that the issue described above is resolved. The repository is checked out at base commit `a6fc2ea158fb`. Edit files in place; the verifier captures your changes via `git diff` and scores them against an oracle patch using SWE-RL-style diff-similarity reward.