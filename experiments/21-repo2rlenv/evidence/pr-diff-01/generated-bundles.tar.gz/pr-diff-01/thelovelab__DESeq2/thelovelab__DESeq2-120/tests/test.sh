#!/bin/bash
set -uxo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd /workspace
git config --global --add safe.directory /workspace
mkdir -p /logs/verifier
rm -f /logs/verifier/reward.txt /logs/verifier/reward.json /logs/verifier/reward-details.json
git add -A
git diff --cached 2877f70a65cedc89c201947e6b971c1806614ca5 > /tmp/predicted.patch
: 'START_VERIFY_OUTPUT'
python3 "$SCRIPT_DIR/verifier.py" \
    "$SCRIPT_DIR/oracle.patch" \
    /tmp/predicted.patch \
    "$SCRIPT_DIR/instruction.md"
: 'END_VERIFY_OUTPUT'
exit 0
