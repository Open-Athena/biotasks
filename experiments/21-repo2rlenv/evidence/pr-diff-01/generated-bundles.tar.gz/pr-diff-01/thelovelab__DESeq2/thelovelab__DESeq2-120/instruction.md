# Issue

**Title:** Implementing greaterAbsUPSHOT

## Description

"greaterAbsUPSHOT" adds a uniform prior for the effect-size distribution to achieve more power than "greaterAbs." We only implement for useT=FALSE for now.

## Task

Modify the repository so that the issue described above is resolved. The repository is checked out at base commit `2877f70a65ce`. Edit files in place; the verifier captures your changes via `git diff` and scores them against an oracle patch using SWE-RL-style diff-similarity reward.