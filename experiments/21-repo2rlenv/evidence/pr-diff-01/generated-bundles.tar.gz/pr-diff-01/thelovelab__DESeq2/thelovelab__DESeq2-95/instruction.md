# Issue

**Title:** Optimize dispersion estimation in estimateDispersionsGeneEst

## Description

Re. PR #64 and our discussion on  I make some adjustments to speed up the process. 

In short, I created the subsetted count matrix `Counts` as in previous version, so that the same subsetting is not performed again and again in the two `vapply` loops to slow things down.

`Counts <- counts(objectNZ)[fitidx,,drop=FALSE]`

Before _optimization_

```r
> system.time({
        dds <- estimateDispersionsGeneEst(dds, type = "glmGamPoi")
})
# using 'glmGamPoi' as fitType. If used in published research, please cite:
#     Ahlmann-Eltze, C., Huber, W. (2020) glmGamPoi: Fitting Gamma-Poisson
#     Generalized Linear Models on Single Cell Count Data. Bioinformatics.
#     https://doi.org/10.1093/bioinformatics/btaa1009
#    user  system elapsed 
# 196.027   3.311 195.619 
```
After _optimization_

```r
> system.time({
        dds <- estimateDispersionsGeneEst(dds, type = "glmGamPoi")
})
# using 'glmGamPoi' as fitType. If used in published research, please cite:
#     Ahlmann-Eltze, C., Huber, W. (2020) glmGamPoi: Fitting Gamma-Poisson
#     Generalized Linear Models on Single Cell Count Data. Bioinformatics.
#     https://doi.org/10.1093/bioinformatics/btaa1009
#    user  system elapsed 
#  11.352   2.980  10.645 
```

## Task

Modify the repository so that the issue described above is resolved. The repository is checked out at base commit `a9171e9814ae`. Edit files in place; the verifier captures your changes via `git diff` and scores them against an oracle patch using SWE-RL-style diff-similarity reward.