# Issue

**Title:** Fix bug on estimateDispersionsGeneEst when niter is larger than 1

## Description

I think I found a minor bug in estimateDispersionsGeneEst when the parameter niter is set to > 1 and `fitType="glmGamPoi"`. 

- The indexing `fitMu[idx, ]` inside the `else if (type == "glmGamPoi")` chunk was not necessary as `fitMu` already has the correct dimensions specified in the line that generates it  (i.e. `fit <- fitNbinomGLMs(objectNZ[fitidx,,drop=FALSE], ...`).
- Also within the interactions across `niter`, when `alpha_hat `and `alpha_hat_new` had both zero values, it returned NA values. This seemed to happen when one of the groups has all zero counts and glmGamPoi is used.

Hope I'm not chasing my own tail here. 

Here is the code that generated the error message:


```
data("pasillaDEXSeqDataSet", package="pasilla")
dxd <- estimateSizeFactors( dxd )
modelMatrix <- DEXSeq:::rmDepCols( model.matrix(design(dxd), as.data.frame(colData(dxd))))
tst <- estimateDispersionsGeneEst( dxd, quiet=FALSE, modelMatrix = modelMatrix, niter = 10, type="glmGamPoi" )

using 'glmGamPoi' as fitType. If used in published research, please cite:
    Ahlmann-Eltze, C., Huber, W. (2020) glmGamPoi: Fitting Gamma-Poisson
    Generalized Linear Models on Single Cell Count Data. Bioinformatics.
    https://doi.org/10.1093/bioinformatics/btaa1009
using 'glmGamPoi' as fitType. If used in published research, please cite:
    Ahlmann-Eltze, C., Huber, W. (2020) glmGamPoi: Fitting Gamma-Poisson
    Generalized Linear Models on Single Cell Count Data. Bioinformatics.
    https://doi.org/10.1093/bioinformatics/btaa1009
Error in fitMu[idx, ] : subscript out of bounds

```

## Task

Modify the repository so that the issue described above is resolved. The repository is checked out at base commit `fce01352c759`. Edit files in place; the verifier captures your changes via `git diff` and scores them against an oracle patch using SWE-RL-style diff-similarity reward.