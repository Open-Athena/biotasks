# Issue

**Title:** Fix w computation subject to useWeights in fitNbinomGLMsOptim

## Description

In the computation of w in fitNbinomGLMsOptim, inverted the actions subject to useWeights, in order to use weights if useWeights is TRUE.

## Task

Modify the repository so that the issue described above is resolved. The repository is checked out at base commit `b34a0f6e2e43`. Edit files in place; the verifier captures your changes via `git diff` and scores them against an oracle patch using SWE-RL-style diff-similarity reward.