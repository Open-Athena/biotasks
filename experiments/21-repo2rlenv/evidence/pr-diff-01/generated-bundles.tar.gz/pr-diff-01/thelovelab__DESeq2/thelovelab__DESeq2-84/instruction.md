# Issue

**Title:** Fix some typos in the vignette

## Description

This PR fixes a couple of typos in the `DESeq2` vignette. 

The changes on line 1574 were made in response to the following warnings: 

```
## Warning: The `fun.y` argument of `stat_summary()` is deprecated as of ggplot2 3.3.0.
## ℹ Please use the `fun` argument instead.
## This warning is displayed once every 8 hours.
## Call `lifecycle::last_lifecycle_warnings()` to see where this warning was
## generated.

## Warning: Using `size` aesthetic for lines was deprecated in ggplot2 3.4.0.
## ℹ Please use `linewidth` instead.
## This warning is displayed once every 8 hours.
## Call `lifecycle::last_lifecycle_warnings()` to see where this warning was
## generated.
```

As a consequence (since I believe `linewidth` was introduced there), I added the requirement of `ggplot2` >=3.4.0 to the `Imports`. Happy to revert back if these were intentionally retained of course.

Finally, a note that [`iSEEde`](https://isee.github.io/iSEEde/) was just accepted into Bioconductor (and should be available soon), in case you would like to add something like this to the bullet point that mentions `iSEE` (cc @kevinrue) 🙂 

```
The [iSEEde](https://bioconductor.org/packages/iSEEde) package provides 
additional panels that facilitate the interactive visualisation of differential 
expression results in iSEE applications.
```

## Task

Modify the repository so that the issue described above is resolved. The repository is checked out at base commit `f6c515ed5ec3`. Edit files in place; the verifier captures your changes via `git diff` and scores them against an oracle patch using SWE-RL-style diff-similarity reward.